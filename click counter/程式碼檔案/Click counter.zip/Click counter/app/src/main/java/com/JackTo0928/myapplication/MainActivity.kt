package com.gotyoubitch.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView


class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val tip: Button=findViewById(R.id.button)
        val re: Button =findViewById(R.id.button2)
        val cc: TextView =findViewById(R.id.count2)
        val count:TextView = findViewById(R.id.count1)
        tip.text="pushme"
        re.text="restart"
        cc.text="Count"
        var clickcount=0

        tip.setOnClickListener{
            clickcount++
            count.text="$clickcount"

        }

        re.setOnClickListener{
            clickcount=0
            count.text="$clickcount"
        }

    }


}