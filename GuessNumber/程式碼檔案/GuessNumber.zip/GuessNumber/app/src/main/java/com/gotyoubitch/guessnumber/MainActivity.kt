package com.gotyoubitch.guessnumber

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.InputType
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val re: Button =findViewById(R.id.button)
        val guess: Button =findViewById(R.id.button2)
        val hehe: Button =findViewById(R.id.button3)
        val num: TextView =findViewById(R.id.textView)
        val gue: TextView = findViewById(R.id.textView2)
        val ans: TextView = findViewById(R.id.textView3)
        val yans: TextView = findViewById(R.id.editTextNumber)
        val kk: TextView = findViewById(R.id.textView4)
        re.text="restart"
        guess.text="guess"
        hehe.text="HeHe"
        num.text="Number"
        gue.text="Your Guess:"
        kk.text="Welcome!"

        var A:Int=0
        //yans.setInputType(InputType.TYPE_CLASS_NUMBER)
        //var In = Integer.parseInt(yans.getText().toString())
        var In=yans.text

        re.setOnClickListener{
            A=(0..200).random()
            yans.text=""
            ans.text=""
        }
        guess.setOnClickListener{
            if(In>A){
                kk.text="input Lower~"
                yans.text=""}
            else if(In<A){
                kk.text="input Higher~"
                yans.text=""
            }
            else{
                kk.text="Good Puppy!"
                yans.text=""
            }
        }
        hehe.setOnClickListener{
            ans.text="$A"
        }
    }
}
